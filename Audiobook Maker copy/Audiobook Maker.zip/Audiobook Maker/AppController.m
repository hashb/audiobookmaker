#import "AppController.h"
#import "TrueCenterTextFieldCell.h"

@implementation AppController
- (void)awakeFromNib {
	TableData = [NSMutableArray new];
	
    NSImageCell *theImageCell = [[NSImageCell alloc] init];
	[theImageCell setImageAlignment:NSImageAlignCenter];
	[theImageCell setImageScaling:NSScaleProportionally];
    [iconColumn setDataCell:theImageCell];
    [theImageCell release];
	
	TrueCenterTextFieldCell *cell = [[TrueCenterTextFieldCell alloc] init];
	[cell setFont:[NSFont fontWithName:@"Lucida Grande" size:12.0]];
	[titleColumn setDataCell:cell];
	[cell release];
	
	//[self createItem:@"/Users/ben/Desktop/TransparentScreen.mov"];

	items=[[NSMutableDictionary alloc] init];

	NSToolbarItem *item=[[NSToolbarItem alloc] initWithItemIdentifier:@"Add"];
	[item setPaletteLabel:@"Add"]; // name for the "Customize Toolbar" sheet
	[item setLabel:@"Add"]; // name for the item in the toolbar
	[item setToolTip:@"Add a portion of the audiobook"]; // tooltip
	[item setTarget:self]; // what should happen when it's clicked
	[item setAction:@selector(addRow:)];
	[item setImage:[NSImage imageNamed:@"Add"]];
	[items setObject:item forKey:@"Add"]; // add to toolbar list
	[item release];
	
	item=[[NSToolbarItem alloc] initWithItemIdentifier:@"Remove"];
	[item setPaletteLabel:@"Delete"]; // name for the "Customize Toolbar" sheet
	[item setLabel:@"Delete"]; // name for the item in the toolbar
	[item setToolTip:@"Remove the selected audio file"]; // tooltip
	[item setTarget:self]; // what should happen when it's clicked
	[item setAction:@selector(deleteRow:)];
	[item setImage:[NSImage imageNamed:@"Remove"]];
	[items setObject:item forKey:@"Remove"]; // add to toolbar list
	[item release];
	
	item=[[NSToolbarItem alloc] initWithItemIdentifier:@"Settings"];
	[item setPaletteLabel:@"Settings"]; // name for the "Customize Toolbar" sheet
	[item setLabel:@"Settings"]; // name for the item in the toolbar
	[item setToolTip:@"Set audiobook details"]; // tooltip
	[item setTarget:self]; // what should happen when it's clicked
	[item setAction:@selector(setInfo:)];
	[item setImage:[NSImage imageNamed:@"Settings"]];
	[items setObject:item forKey:@"Settings"]; // add to toolbar list
	[item release];

	toolbar=[[NSToolbar alloc] initWithIdentifier:@"AudiobookMakerToolbar"]; // identifier has to be unique per window type
	[toolbar setDelegate:self];
	[toolbar setAllowsUserCustomization:YES];
	[toolbar setAutosavesConfiguration:YES];
	
	[mainWindow setToolbar:toolbar];
	
	/*NSNotificationCenter *nCenter =[NSNotificationCenter defaultCenter];
	[nCenter addObserver:self selector:@selector(windowResize:) name:@"NSWindowDidResizeNotification" object:nil];*/

	[mainWindow makeKeyAndOrderFront:nil];
	
	[mainTable setDelegate:self];
	[mainTable setDataSource:self];
//	[mainTable setAutoresizesAllColumnsToFit:YES];
	[mainTable registerForDraggedTypes: [NSArray arrayWithObjects: @"NSGeneralPboardType", nil]];
//	[mainTable setColumnAutoresizingStyle:NSTableViewSequentialColumnAutoresizingStyle];
	
	[self setCurrentPreviewPath:nil];
	QTMovie *temporaryAudioPreviewObject = [QTMovie movieWithFile:nil error:nil];
	[self setAudioPreviewObject:temporaryAudioPreviewObject];
	[audioPreviewObject stop];
	
	[ffButton setPeriodicDelay:0.1 interval:0.3];
	[rwButton setPeriodicDelay:0.1 interval:0.3];
}

-(void)createItem:(NSString *)filePath {
	NSLog(@"Creating item for path: %@", filePath);
	int i;
	for (i=0;i<[TableData count];i++) {
		if ([[[TableData objectAtIndex:i] objectForKey:@"pathColumn"] isEqualToString:filePath]) {
			NSLog(@"Already added");
			[mainTable selectRow:i byExtendingSelection:NO];
			return;
		}
	}
	NSImage *iconimage = [[NSWorkspace sharedWorkspace] iconForFile:filePath];
    [iconimage setSize:NSMakeSize(32, 32)];
	NSString *MediaTitle = [[filePath lastPathComponent] stringByDeletingPathExtension];
	NSMutableDictionary *dict1 = [[NSMutableDictionary alloc] init];
	[dict1 setObject:filePath forKey:@"pathColumn"];
	[dict1 setObject:MediaTitle forKey:@"titleColumn"];
	[dict1 setObject:iconimage forKey:@"iconColumn"];
	[TableData addObject:dict1];
	[dict1 release];
	[mainTable reloadData];
}

- (IBAction)fastForwardPreview:(id)sender {
	[audioPreviewObject stepForward];
	[audioPreviewObject play];
}

- (IBAction)playPreview:(id)sender {
	if (audioPreviewObject!=nil) {
		if ([self isPlaying:audioPreviewObject]) {
			[audioPreviewObject stop];
			[self setPreviewTimer:nil];
		} else {
			NSTimer *tempTime = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(checkPlaybackStatus:) userInfo:nil repeats:YES];
			[self setPreviewTimer:tempTime];
			[audioPreviewObject play];
		}
	[self validatePlaybackButtons];
	}
}

-(void)checkPlaybackStatus:(id)sender {
	[playbackSlider setDoubleValue:[audioPreviewObject currentTime].timeValue];
}

- (IBAction)changePlaybackPosition:(id)sender {
	QTTime currentTime;
	currentTime.timeValue = [sender doubleValue];	// really should be longLongValue
	currentTime.timeScale = timeScale;
	[audioPreviewObject setCurrentTime:currentTime];
}

- (IBAction)rewindPreview:(id)sender {
	[audioPreviewObject stepBackward];
	[audioPreviewObject play];
}

- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSString *)itemIdentifier willBeInsertedIntoToolbar:(BOOL)flag {
    return [items objectForKey:itemIdentifier];
}

- (NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar*)toolbar {
    return [NSArray arrayWithObjects:@"Add", @"Remove",NSToolbarFlexibleSpaceItemIdentifier,@"Settings",nil];
}

- (NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar*)toolbar {
    return [NSArray arrayWithObjects:@"Add",@"Remove",@"Settings",NSToolbarSeparatorItemIdentifier,NSToolbarSpaceItemIdentifier,NSToolbarFlexibleSpaceItemIdentifier,NSToolbarCustomizeToolbarItemIdentifier, nil];
}

-(BOOL)validateToolbarItem: (NSToolbarItem *)item {
	if ([item action] == @selector(deleteRow:)) {
		return [self atLeastOneSelected];
	}
	return YES;
}

- (void)addRow:(NSToolbarItem*)item {
	NSOpenPanel *panel = [NSOpenPanel openPanel];
	[panel setAllowsMultipleSelection:YES];
	[panel setCanCreateDirectories:YES];
	[panel beginSheetForDirectory:nil
							 file:nil
							types:[NSArray arrayWithObjects:@"mp3",nil]
				   modalForWindow:mainWindow
				    modalDelegate:self
				   didEndSelector:@selector(openPanelDidEnd:returnCode:contextInfo:)
					  contextInfo:NULL];
}

-(void)openPanelDidEnd:(NSOpenPanel *)openPanel returnCode:(int)returnCode contextInfo:(void *)contextInfo {
	if (returnCode == NSOKButton) {
        NSArray *filesToOpen = [openPanel filenames];
        int i, fileCount = [filesToOpen count];
        for (i=0; i<fileCount; i++) {
			[self createItem:[filesToOpen objectAtIndex:i]];
        }
	}
}

-(void)refreshTable {
	[mainTable reloadData];
}

-(BOOL)isPlaying:(QTMovie *)aMovie {
	if ([aMovie rate] == 0) {
		return NO;
	}
	return YES;
}

-(BOOL)atLeastOneSelected {
	if ([[mainTable selectedRowIndexes]count]>0) {
		return YES;
	}
	return NO;
}

-(void)validatePlaybackButtons {
	if ([[mainTable selectedRowIndexes]count]>0) {
		[ppButton setEnabled:YES];
		[rwButton setEnabled:YES];
		[ffButton setEnabled:YES];
		[playbackSlider setEnabled:YES];
	} else {
		if ([self isPlaying:audioPreviewObject]==NO) {
		[ppButton setEnabled:NO];
		[rwButton setEnabled:NO];
		[ffButton setEnabled:NO];
		[playbackSlider setEnabled:NO];
		[playbackSlider setIntValue:0];
		}
	}

/*	if ([self isPlaying:audioPreviewObject]) {
		[ppButton setEnabled:YES];
		[rwButton setEnabled:YES];
		[ffButton setEnabled:YES];
		[playbackSlider setEnabled:YES];
	}*/

	if ([self isPlaying:audioPreviewObject]) {
		NSLog(@"switching to pause2");
		[ppButton setImage:[NSImage imageNamed:@"pause"]];
	} else {
		[ppButton setImage:[NSImage imageNamed:@"play"]];
	}

}

-(void)setAudioPreviewObject:(QTMovie *)x {
	[audioPreviewObject stop];
	[audioPreviewObject autorelease];
	audioPreviewObject = [x retain];
}

-(QTMovie *)audioPreviewObject {
	return audioPreviewObject;
}

-(void)setPreviewTimer:(NSTimer *)x {
	[previewTimer invalidate];
	previewTimer = nil;
	previewTimer = [x retain];
}

-(NSTimer *)previewTimer {
	return previewTimer;
}

-(void)setCurrentPreviewPath:(NSString *)x {
	[currentPreviewPath autorelease];
	currentPreviewPath = [x retain];
}

-(NSString *)currentPreviewPath {
	return currentPreviewPath;
}

-(void)tableViewSelectionDidChange:(NSNotification *)notification {
	if ([[mainTable selectedRowIndexes]count]>0) {
		NSString *filePath = [[TableData objectAtIndex:[mainTable selectedRow]] objectForKey:@"pathColumn"];
		if ([self currentPreviewPath]!=filePath) {
			NSLog(@"loadingfile");
			[audioPreviewObject stop];
			[self validatePlaybackButtons];
			QTMovie *temporaryAudioPreviewObject = [QTMovie movieWithFile:filePath error:nil];
			[self setAudioPreviewObject:temporaryAudioPreviewObject];
			[playbackSlider setMaxValue:[audioPreviewObject duration].timeValue];
			timeScale = [[audioPreviewObject attributeForKey:QTMovieTimeScaleAttribute] longValue];
			[self setCurrentPreviewPath:filePath];
		}
	}
	[self validatePlaybackButtons];
}

- (void)windowResize:(NSNotification *)notification
{
	NSLog(@"Window Resizing");
}

- (int)numberOfRowsInTableView:(NSTableView *)tableView {
    return [TableData count];
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(int)row {
	return [[TableData objectAtIndex:row] objectForKey:[tableColumn identifier]];
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex {
	[[TableData objectAtIndex:rowIndex] setObject:anObject forKey:@"titleColumn"];
}

- (void)deleteRow:(NSToolbarItem*)item {
	if ([self atLeastOneSelected]) {
		[TableData removeObjectAtIndex:[mainTable selectedRow]];
		[mainTable reloadData];
		[self validatePlaybackButtons];
	}
}

- (void)setInfo:(NSToolbarItem*)item {

}

- (BOOL) tableView: (NSTableView *) view writeRows: (NSArray *) rows toPasteboard: (NSPasteboard *) pboard {
	id object = [TableData objectAtIndex: [[rows lastObject] intValue]];
	NSData *data = [NSArchiver archivedDataWithRootObject: object];
	dragStartRow = [[rows lastObject] intValue];
	[pboard declareTypes: [NSArray arrayWithObject: @"NSGeneralPboardType"] owner: nil];
	[pboard setData: data forType: @"NSGeneralPboardType"];
	return YES;
}

- (NSDragOperation) tableView: (NSTableView *) view validateDrop: (id <NSDraggingInfo>) info proposedRow: (int) row proposedDropOperation: (NSTableViewDropOperation) operation {
	if (row > [TableData count]) {
		return NSDragOperationNone;
	}

	if (nil == [info draggingSource]) { // From other application
		return NSDragOperationNone;
	} else if (mainTable == [info draggingSource]) { // From self
		if (operation == NSTableViewDropOn) {
			[mainTable setDropRow:(row+1) dropOperation:NSTableViewDropAbove];
		}
		return NSDragOperationMove;
    }
    
	return NSDragOperationNone;
}

- (BOOL) tableView: (NSTableView *) view acceptDrop: (id <NSDraggingInfo>) info row: (int) row dropOperation: (NSTableViewDropOperation) operation {
	NSPasteboard *pboard = [info draggingPasteboard];
	NSData *data = [pboard dataForType: @"NSGeneralPboardType"];
	
	if (row > [TableData count]) {
		return NO;
	}

	if (nil == [info draggingSource]) {	// From other application
		return NO;
	} else if (mainTable == [info draggingSource]) { // From self
		id object = [NSUnarchiver unarchiveObjectWithData: data];
		if (row>1) {
			row = row-1;
		}
		[TableData removeObjectAtIndex:dragStartRow];
		[TableData insertObject: object atIndex: row];
		[mainTable reloadData];
		return YES;
	} else { // From other documents
		return NO;
	}
	return NO;
}

- (IBAction)joinAll:(id)sender {
	[self doJoin];
}

-(void)doJoin {
	NSMutableArray *joinArray = TableData;
	
	//Set up UI
	[joinProgressDescription setStringValue:@""];
	[joinProgressIndicator setMaxValue:[joinArray count]+1];
	[joinProgressIndicator setMinValue:0];
	[joinProgressIndicator setDoubleValue:0];
	[NSApp beginSheet:joinProgressWindow modalForWindow:mainWindow modalDelegate:self didEndSelector:@selector(sheetDidEnd:returnCode:contextInfo:) contextInfo:NULL];
	
	NSString *outputPath = [NSString stringWithFormat:@"%@/Desktop/%@.mp3",NSHomeDirectory(),[outputName stringValue]];
	int i;
	for(i=0;i<[joinArray count];i++) {
		NSLog(@"Copying");
		[joinProgressDescription setStringValue:[[[joinArray objectAtIndex:i] objectForKey:@"pathColumn"] lastPathComponent]];
		[joinProgressIndicator setDoubleValue:i+1];
		NSString *commandString = [NSString stringWithFormat:@"cat '%@'>> '%@'",[[joinArray objectAtIndex:i] objectForKey:@"pathColumn"],outputPath];
		NSTask *cp=[[NSTask alloc] init];
        [cp setLaunchPath:@"/bin/sh"];
//		[cp setArguments:[NSArray arrayWithObjects:[[joinArray objectAtIndex:i] objectForKey:@"pathColumn"],@"/Users/ben/Desktop/1.mp3",nil]];
		[cp setArguments:[NSArray arrayWithObjects:@"-c",commandString,nil]];
		[cp launch];
		[cp waitUntilExit];
        [cp release];
	}
	NSLog(@"Finshed");
	
	[joinProgressDescription setStringValue:@"Converting to proper MP3..."];
	[joinProgressIndicator setDoubleValue:[joinArray count]];
	
	NSString *ffmpegSavePath = [NSString stringWithFormat:@"%@/Desktop/ExportedBook.mp3",NSHomeDirectory()];
	NSTask *ffmpeg=[[NSTask alloc] init];
	NSString *ffmpegPath = [[NSBundle mainBundle] pathForResource:@"ffmpeg" ofType:@""];
	NSString *ffmpegCommandString = [NSString stringWithFormat:@"'%@' -i %@ -vn -ab %@ -acodec mp3 -ac 1 '%@'",ffmpegPath,outputPath,[outputRate stringValue],ffmpegSavePath];
	NSLog(@"%@",ffmpegPath);
    [ffmpeg setLaunchPath:@"/bin/sh"];
	[ffmpeg setArguments:[NSArray arrayWithObjects:@"-c",ffmpegCommandString,nil]];
	[ffmpeg launch];
	[ffmpeg waitUntilExit];
    [ffmpeg release];
	

	
	[joinProgressWindow orderOut:self];
	[NSApp endSheet:joinProgressWindow returnCode:1];
}

-(void)sheetDidEnd:(NSWindow *)sheetDidEnd returnCode:(int)returnCode contextInfo:(void *)contextInfo {

}
@end
