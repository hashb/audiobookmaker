/* TrueCenterTextFieldCell */

#import <Cocoa/Cocoa.h>

@interface TrueCenterTextFieldCell : NSTextFieldCell
{

}
- (NSRect)textRectForFrame:(NSRect)frame;
//- (void)textDidEndEditing:(NSNotification *)aNotification;

@end
