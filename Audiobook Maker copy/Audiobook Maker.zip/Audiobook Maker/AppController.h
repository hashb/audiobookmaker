/* AppController */

#import <Cocoa/Cocoa.h>
#import <QTKit/QTKit.h>

@interface AppController : NSObject
{
    IBOutlet NSWindow *mainWindow;
	IBOutlet NSTableColumn *iconColumn;
	IBOutlet NSTableColumn *titleColumn;
//	IBOutlet NSTableColumn *durationColumn;

	IBOutlet NSButton *ffButton;
	IBOutlet NSButton *rwButton;
	IBOutlet NSButton *ppButton;

    NSToolbar *toolbar;
    NSMutableDictionary *items;
	IBOutlet NSTableView *mainTable;
	
	NSMutableArray* TableData;
	unsigned dragStartRow;
	
	QTMovie* audioPreviewObject;
	long timeScale;
	NSTimer *previewTimer;
	IBOutlet NSSlider *playbackSlider;
	NSString *currentPreviewPath;
	
	IBOutlet NSWindow *joinProgressWindow;
	IBOutlet NSTextField *joinProgressDescription;
	IBOutlet NSProgressIndicator *joinProgressIndicator;
	
	IBOutlet NSWindow *outputWindow;
	IBOutlet NSTextField *outputName;
	IBOutlet NSTextField *outputRate;
	IBOutlet NSButton *outputBookmarked;
}

- (void)awakeFromNib;

// Toolbar Stuff
- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSString *)itemIdentifier willBeInsertedIntoToolbar:(BOOL)flag;
- (NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar*)toolbar;
- (NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar*)toolbar;
-(BOOL)validateToolbarItem: (NSToolbarItem *)item;

// TableView Stuff
- (int)numberOfRowsInTableView:(NSTableView *)tableView;
- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(int)row;
- (void)addRow:(NSToolbarItem*)item;
- (void)setInfo:(NSToolbarItem*)item;
-(BOOL)atLeastOneSelected;

-(void)checkPlaybackStatus:(id)sender;

- (void)windowResize:(NSNotification *)notification;

- (void)deleteRow:(NSToolbarItem*)item;
-(void)refreshTable;
-(void)createItem:(NSString *)filePath;
-(void)tableViewSelectionDidChange:(NSNotification *)notification;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex;

// TableView Drag'n'Drop
- (BOOL) tableView: (NSTableView *) view acceptDrop: (id <NSDraggingInfo>) info row: (int) row dropOperation: (NSTableViewDropOperation) operation;
- (NSDragOperation) tableView: (NSTableView *) view validateDrop: (id <NSDraggingInfo>) info proposedRow: (int) row proposedDropOperation: (NSTableViewDropOperation) operation;
- (BOOL) tableView: (NSTableView *) view writeRows: (NSArray *) rows toPasteboard: (NSPasteboard *) pboard;

// Preview song
- (IBAction)fastForwardPreview:(id)sender;
- (IBAction)playPreview:(id)sender;
- (IBAction)rewindPreview:(id)sender;
-(void)validatePlaybackButtons;
-(void)setAudioPreviewObject:(QTMovie *)x;
-(QTMovie *)audioPreviewObject;
-(void)setPreviewTimer:(NSTimer *)x;
-(NSTimer *)previewTimer;
- (IBAction)changePlaybackPosition:(id)sender;
-(BOOL)isPlaying:(QTMovie *)aMovie;
-(void)setCurrentPreviewPath:(NSString *)x;
-(NSString *)currentPreviewPath;

-(void)openPanelDidEnd:(NSOpenPanel *)openPanel returnCode:(int)returnCode contextInfo:(void *)contextInfo;

- (IBAction)joinAll:(id)sender;
-(void)doJoin;
-(void)sheetDidEnd:(NSWindow *)sheetDidEnd returnCode:(int)returnCode contextInfo:(void *)contextInfo;
@end
